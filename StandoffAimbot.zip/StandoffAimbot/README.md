# Standoff 2 Aimbot

Android aimbot สำหรับ Standoff 2 ทำงานผ่าน GitHub Actions

## วิธีการ

### 1. สร้าง GitHub Account
- ไปที่ github.com
- Sign Up (ฟรี)
- ยืนยัน email

### 2. สร้าง Repository
- Click + (มุมขวาบน) → New repository
- ชื่อ: `StandoffAimbot`
- เลือก Public
- Create repository

### 3. อัปโหลดไฟล์
Clone ตัวนี้ลงมา หรือ:
- Click "Add file" → Upload files
- อัปโหลดไฟล์ทั้งหมด:
  - `build.gradle`
  - `settings.gradle`
  - `android-build.yml` → ใส่ใน `.github/workflows/`
  - `AndroidManifest.xml` → ใส่ใน `app/src/main/`
  - Kotlin files (`.kt`) → ใส่ใน `app/src/main/java/com/standoff/aimbot/`
  - XML files → ใส่ใน `app/src/main/res/` (สร้างโฟลเดอร์: values, xml, layout)

### 4. GitHub Actions Build
- ไปที่ Actions tab
- Build APK จะเริ่มเอง
- รอให้ complete (5-10 นาที)
- Download APK จาก Artifacts

### 5. ติดตั้งบนมือถือ
- เปิด USB Debugging บน Android
- เชื่อม USB กับ PC ที่มี ADB
- หรือ: ส่ง APK ผ่าน LINE/Telegram แล้วกดติดตั้ง

### 6. เปิดใช้งาน
- เปิดแอป → กด "เริ่ม Aimbot"
- ตั้งค่า → สิทธิ์การเข้าถึง → เปิด Standoff Aimbot
- กลับมากด "เริ่ม" อีกครั้ง
- อนุญาตจับภาพหน้าจอ
- **เสร็จ** — เห็นกล่องสีเขียวรอบศัตรูแล้ว

## File Structure
```
StandoffAimbot/
├── build.gradle
├── settings.gradle
├── .github/
│   └── workflows/
│       └── android-build.yml
├── app/
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/
│           │   └── com/standoff/aimbot/
│           │       ├── MainActivity.kt
│           │       ├── ScreenCaptureService.kt
│           │       ├── PlayerDetector.kt
│           │       ├── AimbotOverlayView.kt
│           │       └── AimbotAccessibilityService.kt
│           └── res/
│               ├── layout/
│               │   └── activity_main.xml
│               ├── values/
│               │   └── strings.xml
│               └── xml/
│                   └── accessibility_service_config.xml
```

## หมายเหตุ
- ไม่ต้องรูท
- ตรวจไม่เจอ (ใช้ accessibility service)
- ใช้ color detection แบบ real-time
- Overlay แสดงกล่องสีเขียวรอบศัตรู
