package com.standoff.aimbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var overlayView: AimbotOverlayView? = null
    private var detector: PlayerDetector? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = Notification.Builder(this, "aimbot_channel")
            .setContentTitle("Standoff 2 Aimbot")
            .setContentText("กำลังทำงาน...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        startForeground(1, notification)

        val resultCode = intent?.getIntExtra("resultCode", -1) ?: return START_STICKY
        val data = intent?.getParcelableExtra<Intent>("data") ?: return START_STICKY

        val mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data)

        initCapture()
        startDetector()

        return START_STICKY
    }

    private fun initCapture() {
        val screenWidth = 1080
        val screenHeight = 2340

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, android.graphics.PixelFormat.RGBA_8888, 2)

        captureThread = HandlerThread("ScreenCapture").apply { start() }
        captureHandler = Handler(captureThread!!.looper)

        val surfaceTexture = imageReader!!.surface
        mediaProjection?.createVirtualDisplay(
            "aimbot",
            screenWidth,
            screenHeight,
            resources.displayMetrics.densityDpi,
            0,
            surfaceTexture,
            null,
            captureHandler
        )

        overlayView = AimbotOverlayView(this)

        captureHandler?.post {
            captureFrame()
        }
    }

    private fun captureFrame() {
        try {
            val image = imageReader?.acquireLatestImage() ?: return
            val planes = image.planes
            val buffer = planes[0].buffer
            buffer.rewind()

            val pixelStride = planes[0].pixelStride
            val rowPadding = planes[0].rowPadding - pixelStride * image.width
            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )

            bitmap.copyPixelsFromBuffer(buffer)
            image.close()

            detector?.detectPlayers(bitmap) { targets ->
                overlayView?.updateTargets(targets)
            }

            captureHandler?.postDelayed({ captureFrame() }, 33)
        } catch (e: Exception) {
            Log.e("ScreenCapture", "Error", e)
        }
    }

    private fun startDetector() {
        detector = PlayerDetector(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "aimbot_channel",
                "Aimbot Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        imageReader?.close()
        mediaProjection?.stop()
        captureThread?.quit()
        overlayView?.destroy()
    }
}
