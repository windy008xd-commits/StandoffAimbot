package com.standoff.aimbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Log
import kotlin.math.sqrt

data class Target(val x: Float, val y: Float, val confidence: Float, val box: RectF)

class PlayerDetector(private val context: Context) {

    private val confidence_threshold = 0.5f

    init {
        Log.d("PlayerDetector", "Detector initialized")
    }

    fun detectPlayers(bitmap: Bitmap, callback: (List<Target>) -> Unit) {
        try {
            val targets = mutableListOf<Target>()

            val centerX = bitmap.width / 2f
            val centerY = bitmap.height / 2f

            // Simple color-based detection for red/brown colors (enemy uniforms)
            val pixels = IntArray(bitmap.width * bitmap.height)
            bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

            val detectedAreas = findColorRegions(pixels, bitmap.width, bitmap.height)

            for (area in detectedAreas) {
                val confidence = (area.confidence * 100).coerceIn(0f, 100f) / 100f
                targets.add(
                    Target(
                        area.centerX,
                        area.centerY,
                        confidence,
                        RectF(area.left, area.top, area.right, area.bottom)
                    )
                )
            }

            callback(targets.sortedByDescending { it.confidence }.take(10))
        } catch (e: Exception) {
            Log.e("PlayerDetector", "Detection error", e)
            callback(emptyList())
        }
    }

    private fun findColorRegions(pixels: IntArray, width: Int, height: Int): List<DetectionArea> {
        val regions = mutableListOf<DetectionArea>()
        val visited = BooleanArray(pixels.size)

        for (i in pixels.indices) {
            if (!visited[i] && isEnemyColor(pixels[i])) {
                val region = floodFill(pixels, visited, i, width, height)
                if (region.pixelCount > 100) {
                    regions.add(region)
                }
            }
        }

        return regions
    }

    private fun isEnemyColor(pixel: Int): Boolean {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF

        // Detect red/brown colors typical of enemy uniforms
        return r > 150 && g < 100 && b < 100
    }

    private fun floodFill(
        pixels: IntArray,
        visited: BooleanArray,
        startIdx: Int,
        width: Int,
        height: Int
    ): DetectionArea {
        val queue = mutableListOf(startIdx)
        val indices = mutableListOf<Int>()

        var left = Int.MAX_VALUE
        var top = Int.MAX_VALUE
        var right = 0
        var bottom = 0

        while (queue.isNotEmpty()) {
            val idx = queue.removeAt(0)
            if (visited[idx]) continue

            visited[idx] = true
            indices.add(idx)

            val y = idx / width
            val x = idx % width

            left = minOf(left, x)
            top = minOf(top, y)
            right = maxOf(right, x)
            bottom = maxOf(bottom, y)

            val neighbors = listOf(
                idx - width, idx + width,
                idx - 1, idx + 1
            )

            for (neighbor in neighbors) {
                if (neighbor >= 0 && neighbor < pixels.size && !visited[neighbor] && isEnemyColor(pixels[neighbor])) {
                    queue.add(neighbor)
                }
            }
        }

        val centerX = ((left + right) / 2).toFloat()
        val centerY = ((top + bottom) / 2).toFloat()

        return DetectionArea(
            left.toFloat(), top.toFloat(),
            right.toFloat(), bottom.toFloat(),
            centerX, centerY, indices.size.toFloat(), 0.75f
        )
    }
}

data class DetectionArea(
    val left: Float, val top: Float,
    val right: Float, val bottom: Float,
    val centerX: Float, val centerY: Float,
    val pixelCount: Float, val confidence: Float
)
