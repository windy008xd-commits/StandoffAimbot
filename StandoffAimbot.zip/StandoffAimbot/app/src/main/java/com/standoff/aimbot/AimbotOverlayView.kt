package com.standoff.aimbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import kotlin.math.sqrt

class AimbotOverlayView(context: Context) : View(context) {

    private val paint = Paint().apply {
        color = Color.GREEN
        strokeWidth = 3f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val crosshairPaint = Paint().apply {
        color = Color.RED
        strokeWidth = 2f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = true
    }

    private var targets = listOf<Target>()
    private var closestTarget: Target? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    init {
        setBackgroundColor(Color.TRANSPARENT)
        addToWindow(context)
    }

    fun updateTargets(newTargets: List<Target>) {
        mainHandler.post {
            targets = newTargets
            closestTarget = findClosestTarget()
            invalidate()
        }
    }

    private fun findClosestTarget(): Target? {
        val screenCenterX = width / 2f
        val screenCenterY = height / 2f

        return targets.minByOrNull { target ->
            val dx = target.x - screenCenterX
            val dy = target.y - screenCenterY
            sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val screenCenterX = width / 2f
        val screenCenterY = height / 2f

        // Draw center crosshair
        canvas.drawLine(screenCenterX - 50, screenCenterY, screenCenterX + 50, screenCenterY, crosshairPaint)
        canvas.drawLine(screenCenterX, screenCenterY - 50, screenCenterX, screenCenterY + 50, crosshairPaint)

        // Draw detected targets
        for (target in targets) {
            canvas.drawRect(target.box, paint)
            canvas.drawText("${(target.confidence * 100).toInt()}%", target.box.left, target.box.top - 10, textPaint)
        }

        // Highlight closest target
        closestTarget?.let { target ->
            val highlightPaint = Paint().apply {
                color = Color.YELLOW
                strokeWidth = 5f
                style = Paint.Style.STROKE
            }
            canvas.drawRect(target.box, highlightPaint)
        }
    }

    private fun addToWindow(context: Context) {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            format = android.graphics.PixelFormat.TRANSLUCENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        windowManager.addView(this, params)
    }

    fun destroy() {
        try {
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
