package com.standoff.aimbot

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class AimbotAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
    }
}
